# Author: Erik Bobinski
# 9/11/2024
# Description: I/O for first and last name

firstName = input("Input your first name: ")
lastName = input("Input your last name: ")

print("Your full name is: " + lastName + ", " + firstName) 
